import { v4 as uuidv4 } from 'uuid';

/**
 * Generate a unique reference number for payment transactions
 * Format: REF-XXXXXXXX-XXXX-XXXX (shortened UUID)
 */
export function generateReferenceNumber(): string {
  const uuid = uuidv4().replace(/-/g, '').substring(0, 16);
  return `REF-${uuid.substring(0, 8)}-${uuid.substring(8, 12)}-${uuid.substring(12, 16)}`;
}

/**
 * Calculate next due date for subscription (30 calendar days / 22 business days)
 * Business days = Monday to Friday only
 */
export function calculateNextDueDate(fromDate: Date = new Date()): Date {
  const nextDate = new Date(fromDate);
  nextDate.setDate(nextDate.getDate() + 30);
  return nextDate;
}

/**
 * Calculate next business day (Monday-Friday only)
 */
export function getNextBusinessDay(date: Date = new Date()): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + 1);
  
  // 0 = Sunday, 6 = Saturday
  while (next.getDay() === 0 || next.getDay() === 6) {
    next.setDate(next.getDate() + 1);
  }
  
  return next;
}

/**
 * Check if a date is a business day (Monday-Friday)
 */
export function isBusinessDay(date: Date): boolean {
  const day = date.getDay();
  return day !== 0 && day !== 6;
}

/**
 * Format currency in Nigerian Naira
 */
export function formatNaira(amount: number | string): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return `₦${num.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate password strength
 * Requirements: min 8 chars, uppercase, lowercase, numbers, special chars
 */
export function isValidPassword(password: string): boolean {
  if (password.length < 8) return false;
  if (!/[A-Z]/.test(password)) return false;
  if (!/[a-z]/.test(password)) return false;
  if (!/[0-9]/.test(password)) return false;
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) return false;
  return true;
}

/**
 * Get password validation error message
 */
export function getPasswordValidationError(password: string): string | null {
  if (password.length < 8) return 'Password must be at least 8 characters long';
  if (!/[A-Z]/.test(password)) return 'Password must contain at least one uppercase letter';
  if (!/[a-z]/.test(password)) return 'Password must contain at least one lowercase letter';
  if (!/[0-9]/.test(password)) return 'Password must contain at least one number';
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) return 'Password must contain at least one special character';
  return null;
}
