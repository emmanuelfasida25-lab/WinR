import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  getUserById, getSubscriptionByUserId, getPaymentsByUserId, 
  getWithdrawalsByUserId, getReferralsByReferrerId, getAllUsers,
  getAllPayments, getAllWithdrawals, getNotificationsByUserId,
  getSupportTicketsByUserId, getAllSupportTickets, getDb
} from "./db";
import { generateReferenceNumber, formatNaira } from "./utils";
import { 
  subscriptions, payments, withdrawals, referrals,
  notifications, supportTickets, balanceUpdates, users
} from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

// Helper to ensure user is admin
function ensureAdmin(ctx: any) {
  if (ctx.user?.role !== 'admin') {
    throw new Error('Admin access required');
  }
}

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // User Dashboard Procedures
  user: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      return await getUserById(ctx.user.id);
    }),

    updateProfile: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        phoneNumber: z.string().optional(),
        bankName: z.string().optional(),
        accountNumber: z.string().optional(),
        accountName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(users)
          .set({
            ...input,
            updatedAt: new Date(),
          })
          .where(eq(users.id, ctx.user.id));
        
        return { success: true };
      }),

    getSubscription: protectedProcedure.query(async ({ ctx }) => {
      return await getSubscriptionByUserId(ctx.user.id);
    }),

    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      return {
        balance: user?.currentBalance || '0',
        accountStatus: user?.accountStatus || 'pending',
      };
    }),

    getTransactionHistory: protectedProcedure.query(async ({ ctx }) => {
      const userPayments = await getPaymentsByUserId(ctx.user.id);
      return userPayments.map(p => ({
        id: p.id,
        type: 'payment',
        amount: p.amount,
        status: p.paymentStatus,
        date: p.paymentDate,
      }));
    }),

    getNotifications: protectedProcedure.query(async ({ ctx }) => {
      return await getNotificationsByUserId(ctx.user.id);
    }),

    markNotificationAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(notifications)
          .set({ isRead: true })
          .where(eq(notifications.id, input.notificationId));
        
        return { success: true };
      }),
  }),

  // Payment Procedures
  payment: router({
    initiateFundWallet: protectedProcedure
      .input(z.object({
        amount: z.number().positive('Amount must be positive'),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        const referenceNumber = generateReferenceNumber();
        
        const result = await db.insert(payments).values({
          userId: ctx.user.id,
          amount: input.amount.toString(),
          referenceNumber,
          paymentStatus: 'pending',
          paymentMethod: 'manual',
        });
        
        return {
          referenceNumber,
          amount: input.amount,
          bankName: 'First Bank Nigeria',
          accountNumber: '3012884456',
          accountName: 'WinR Holdings Ltd',
        };
      }),

    confirmTransfer: protectedProcedure
      .input(z.object({
        referenceNumber: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        const payment = await db.select().from(payments)
          .where(eq(payments.referenceNumber, input.referenceNumber))
          .limit(1);
        
        if (!payment || payment.length === 0) {
          throw new Error('Payment not found');
        }
        
        if (payment[0].userId !== ctx.user.id) {
          throw new Error('Unauthorized');
        }
        
        await db.update(payments)
          .set({ paymentStatus: 'pending' })
          .where(eq(payments.referenceNumber, input.referenceNumber));
        
        return { success: true, status: 'pending' };
      }),

    getPaymentHistory: protectedProcedure.query(async ({ ctx }) => {
      return await getPaymentsByUserId(ctx.user.id);
    }),
  }),

  // Withdrawal Procedures
  withdrawal: router({
    requestWithdrawal: protectedProcedure
      .input(z.object({
        amount: z.number().positive(),
        bankName: z.string(),
        accountNumber: z.string(),
        accountName: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        // Check if withdrawal is enabled for this user
        const user = await getUserById(ctx.user.id);
        if (!user) throw new Error('User not found');
        
        // Check if user has sufficient balance
        const balance = parseFloat(user.currentBalance?.toString() || '0');
        if (balance < input.amount) {
          throw new Error('Insufficient balance');
        }
        
        const result = await db.insert(withdrawals).values({
          userId: ctx.user.id,
          amount: input.amount.toString(),
          bankName: input.bankName,
          accountNumber: input.accountNumber,
          accountName: input.accountName,
          withdrawalStatus: 'pending',
        });
        
        return { success: true, message: 'Withdrawal request submitted' };
      }),

    getWithdrawalHistory: protectedProcedure.query(async ({ ctx }) => {
      return await getWithdrawalsByUserId(ctx.user.id);
    }),
  }),

  // Referral Procedures
  referral: router({
    getReferralData: protectedProcedure.query(async ({ ctx }) => {
      const userReferrals = await getReferralsByReferrerId(ctx.user.id);
      const successfulReferrals = userReferrals.filter(r => r.referralStatus === 'active');
      const totalEarned = successfulReferrals.reduce((sum, r) => sum + parseFloat(r.earnedAmount?.toString() || '0'), 0);
      
      return {
        totalReferrals: userReferrals.length,
        successfulReferrals: successfulReferrals.length,
        totalEarned,
        referralLink: `${process.env.VITE_APP_ID || 'app'}/signup?ref=${ctx.user.id}`,
        referrals: userReferrals,
      };
    }),
  }),

  // Support Procedures
  support: router({
    createTicket: protectedProcedure
      .input(z.object({
        subject: z.string(),
        message: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.insert(supportTickets).values({
          userId: ctx.user.id,
          subject: input.subject,
          message: input.message,
          status: 'open',
        });
        
        return { success: true };
      }),

    getTickets: protectedProcedure.query(async ({ ctx }) => {
      return await getSupportTicketsByUserId(ctx.user.id);
    }),
  }),

  // Admin Procedures
  admin: router({
    // Dashboard
    getDashboardStats: protectedProcedure.query(async ({ ctx }) => {
      ensureAdmin(ctx);
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      const allUsers = await getAllUsers();
      const allPayments = await getAllPayments();
      const allWithdrawals = await getAllWithdrawals();
      
      const activeSubscribers = allUsers.filter(u => u.accountStatus === 'active').length;
      const pendingWithdrawals = allWithdrawals.filter(w => w.withdrawalStatus === 'pending');
      const totalPaidOut = allWithdrawals
        .filter(w => w.withdrawalStatus === 'paid')
        .reduce((sum, w) => sum + parseFloat(w.amount?.toString() || '0'), 0);
      
      return {
        totalUsers: allUsers.length,
        activeSubscribers,
        pendingWithdrawalsCount: pendingWithdrawals.length,
        pendingWithdrawalsAmount: pendingWithdrawals.reduce((sum, w) => sum + parseFloat(w.amount?.toString() || '0'), 0),
        totalPaidOut,
      };
    }),

    // Users Management
    getAllUsers: protectedProcedure.query(async ({ ctx }) => {
      ensureAdmin(ctx);
      return await getAllUsers();
    }),

    getUserDetails: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const user = await getUserById(input.userId);
        const subscription = await getSubscriptionByUserId(input.userId);
        const payments = await getPaymentsByUserId(input.userId);
        const withdrawals = await getWithdrawalsByUserId(input.userId);
        
        return { user, subscription, payments, withdrawals };
      }),

    // Balance Management
    updateUserBalance: protectedProcedure
      .input(z.object({
        userId: z.number(),
        newBalance: z.number(),
        category: z.enum(['account_topup', 'daily_update', 'other']),
        note: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        const user = await getUserById(input.userId);
        if (!user) throw new Error('User not found');
        
        const previousBalance = parseFloat(user.currentBalance?.toString() || '0');
        
        await db.update(users)
          .set({ currentBalance: input.newBalance.toString() })
          .where(eq(users.id, input.userId));
        
        await db.insert(balanceUpdates).values({
          userId: input.userId,
          previousBalance: previousBalance.toString(),
          newBalance: input.newBalance.toString(),
          updateCategory: input.category,
          note: input.note,
          updatedBy: ctx.user.id,
        });
        
        return { success: true };
      }),

    // Payments Management
    getAllPayments: protectedProcedure.query(async ({ ctx }) => {
      ensureAdmin(ctx);
      return await getAllPayments();
    }),

    confirmPayment: protectedProcedure
      .input(z.object({ paymentId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        const payment = await db.select().from(payments)
          .where(eq(payments.id, input.paymentId))
          .limit(1);
        
        if (!payment || payment.length === 0) {
          throw new Error('Payment not found');
        }
        
        const p = payment[0];
        
        // Update payment status
        await db.update(payments)
          .set({
            paymentStatus: 'confirmed',
            confirmedDate: new Date(),
            confirmedBy: ctx.user.id,
          })
          .where(eq(payments.id, input.paymentId));
        
        // Update user balance
        const user = await getUserById(p.userId);
        if (user) {
          const currentBalance = parseFloat(user.currentBalance?.toString() || '0');
          const newBalance = currentBalance + parseFloat(p.amount?.toString() || '0');
          
          await db.update(users)
            .set({
              currentBalance: newBalance.toString(),
              accountStatus: 'active',
            })
            .where(eq(users.id, p.userId));
          
          // Update subscription
          const sub = await getSubscriptionByUserId(p.userId);
          if (sub) {
            const nextDueDate = new Date();
            nextDueDate.setDate(nextDueDate.getDate() + 30);
            
            await db.update(subscriptions)
              .set({
                subscriptionStatus: 'active',
                lastPaymentDate: new Date(),
                nextDueDate,
              })
              .where(eq(subscriptions.id, sub.id));
          }
        }
        
        return { success: true };
      }),

    // Withdrawals Management
    getAllWithdrawals: protectedProcedure.query(async ({ ctx }) => {
      ensureAdmin(ctx);
      return await getAllWithdrawals();
    }),

    approveWithdrawal: protectedProcedure
      .input(z.object({ withdrawalId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(withdrawals)
          .set({
            withdrawalStatus: 'approved',
            approvedDate: new Date(),
            approvedBy: ctx.user.id,
          })
          .where(eq(withdrawals.id, input.withdrawalId));
        
        return { success: true };
      }),

    rejectWithdrawal: protectedProcedure
      .input(z.object({ withdrawalId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(withdrawals)
          .set({ withdrawalStatus: 'rejected' })
          .where(eq(withdrawals.id, input.withdrawalId));
        
        return { success: true };
      }),

    // Support Tickets
    getAllSupportTickets: protectedProcedure.query(async ({ ctx }) => {
      ensureAdmin(ctx);
      return await getAllSupportTickets();
    }),

    resolveTicket: protectedProcedure
      .input(z.object({ ticketId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        ensureAdmin(ctx);
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        
        await db.update(supportTickets)
          .set({ status: 'resolved', resolvedAt: new Date() })
          .where(eq(supportTickets.id, input.ticketId));
        
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
