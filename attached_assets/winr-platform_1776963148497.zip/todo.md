# WINR Platform - Project TODO

## Phase 1: Database Schema & Authentication
- [x] Define database tables: users, subscriptions, payments, withdrawals, referrals, affiliate_withdrawals, admin_actions, balance_updates, support_tickets, notifications
- [x] Implement Row Level Security (RLS) policies for all tables
- [x] Set up Supabase Auth with email/password and email verification
- [x] Configure JWT token expiration (1 hour access, 7 days refresh)
- [x] Create auth middleware and role-based access control (RBAC)
- [x] Implement password validation (min 8 chars, uppercase, lowercase, numbers, special chars)

## Phase 2: Public Landing Page
- [x] Create landing page layout with hero section
- [x] Add navigation bar with Login and Sign Up buttons
- [x] Build features/how-it-works section (4-step process cards)
- [x] Build pricing section with ₦3,500/month subscription display
- [x] Add statistics section (total users, active subscribers, total paid out)
- [x] Implement responsive design for mobile and desktop

## Phase 3: Authentication Pages
- [x] Build signup page with email verification flow
- [x] Build login page with email and password
- [ ] Implement password reset flow
- [ ] Add email verification confirmation page
- [x] Create error handling and validation messages

## Phase 4: User Dashboard - Overview
- [x] Build dashboard layout with sidebar navigation
- [x] Display current balance prominently with gold accent
- [x] Show account status (active/pending/inactive) with visual indicators
- [x] Display subscription status with last payment and next due date
- [x] Show quick action buttons (Fund Wallet, Withdraw Funds)
- [x] Display recent transaction history table

## Phase 5: User Dashboard - Fund Wallet
- [x] Create fund wallet modal/page
- [x] Implement unique reference number generation (UUID v4)
- [x] Display bank details: First Bank Nigeria, 3012884456, WinR Holdings Ltd
- [x] Show generated reference number prominently
- [x] Implement "I have made the transfer" button
- [x] Mark transaction as pending after confirmation
- [x] Display confirmation message to user

## Phase 6: User Dashboard - Withdrawals
- [x] Create withdrawal request form
- [ ] Implement withdrawal button (disabled by default, enabled by admin)
- [x] Allow users to specify amount and bank details
- [x] Display withdrawal history with status tracking
- [x] Show pending/approved/rejected/paid statuses

## Phase 7: User Dashboard - Affiliate Section
- [ ] Display total referrals count
- [ ] Show total earned amount and pending earnings
- [ ] Create unique referral link with copy-to-clipboard
- [ ] Display referral activity table
- [ ] Implement affiliate withdrawal button (disabled until 10 successful referrals)
- [ ] Calculate affiliate earnings (₦500 per confirmed referral)

## Phase 8: User Dashboard - Settings & Support
- [ ] Build settings page for profile updates (name, phone, email)
- [ ] Implement bank account details management
- [ ] Create secure password change flow
- [ ] Build support section with contact form
- [ ] Add WhatsApp integration button
- [ ] Display notifications with mark as read functionality

## Phase 9: Admin Dashboard - Overview
- [x] Create admin dashboard layout
- [x] Display key metrics (total users, active subscribers, pending withdrawals)
- [x] Show recent signups table with status indicators
- [x] Display pending withdrawals table with quick approval buttons
- [x] Add alert banner for pending actions

## Phase 10: Admin Dashboard - Users Management
- [x] Build searchable, filterable users table
- [x] Add columns: name, email, phone, joined date, status, last subscription payment, next due date
- [x] Implement "View" button for user details
- [ ] Add "Send Reminder" button for subscription reminders
- [ ] Display user detail view with profile, subscription history, transaction history

## Phase 11: Admin Dashboard - Balance Management
- [ ] Create balance update interface
- [ ] Implement dropdown for update categories (Account Topup, Daily Update, etc.)
- [ ] Display recent balance updates table
- [ ] Send notifications to users upon balance update

## Phase 12: Admin Dashboard - Payments & Subscriptions
- [x] Display all subscription payments table
- [x] Add columns: user, amount, payment method, date, status
- [x] Implement payment confirmation logic (pending → active account)
- [x] Add "Confirm" button for pending manual payments
- [ ] Restrict account features for pending/expired subscriptions

## Phase 13: Admin Dashboard - Withdrawals
- [x] Display all withdrawal requests with status filtering
- [x] Show user name, amount, bank details, requested date
- [x] Implement "Approve" and "Reject" buttons
- [x] Display withdrawal history with all processed requests

## Phase 14: Admin Dashboard - Affiliate Earnings
- [ ] Display total referrals and confirmed referrals
- [ ] Show pending payout amounts
- [ ] Create referral table with referrer, referred user, status, earnings
- [ ] Implement "Mark Paid" button for unpaid referrals

## Phase 15: Admin Dashboard - Support & Data Export
- [ ] Display open support tickets with user info and timestamps
- [ ] Implement reply interface for admins
- [ ] Add data export functionality (CSV/Excel)
- [ ] Export users, payments, withdrawals, affiliate earnings

## Phase 16: Security Implementation
- [ ] Implement HTTPS/TLS 1.3 encryption
- [ ] Add CSRF protection with SameSite cookies
- [ ] Implement rate limiting (5 failed login attempts = 15 min lockout)
- [ ] Add Content Security Policy (CSP) headers
- [ ] Implement X-Frame-Options and X-Content-Type-Options headers
- [ ] Add Strict-Transport-Security (HSTS) header
- [ ] Implement comprehensive logging for security events

## Phase 17: Business Logic & Calculations
- [ ] Implement subscription status tracking (active/pending/expired)
- [ ] Calculate next due date (30 calendar days / 22 business days, Monday-Friday only)
- [ ] Implement account restrictions for pending/expired subscriptions
- [ ] Implement referral tracking and earnings calculation
- [ ] Implement affiliate withdrawal eligibility (10+ successful referrals)

## Phase 18: Testing & Polish
- [ ] Write unit tests for utility functions and business logic
- [ ] Write integration tests for API routes
- [ ] Test critical user flows (signup, payment, withdrawal)
- [ ] Test admin approval workflows
- [ ] Verify responsive design across devices
- [ ] Test accessibility (WCAG 2.1 AA compliance)
- [ ] Performance optimization and Core Web Vitals

## Phase 19: Deployment & Documentation
- [ ] Set up CI/CD pipeline with GitHub Actions
- [ ] Implement staging environment
- [ ] Deploy to production
- [ ] Create user documentation
- [ ] Create admin documentation
