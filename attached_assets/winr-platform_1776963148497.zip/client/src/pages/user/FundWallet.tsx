import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Copy, Check } from "lucide-react";
import { toast } from "sonner";

export default function FundWallet() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [amount, setAmount] = useState("");
  const [step, setStep] = useState<"input" | "details" | "confirmed">("input");
  const [referenceNumber, setReferenceNumber] = useState("");
  const [copied, setCopied] = useState(false);

  const initiateFundWallet = trpc.payment.initiateFundWallet.useMutation();
  const confirmTransfer = trpc.payment.confirmTransfer.useMutation();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const handleInitiate = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    try {
      const result = await initiateFundWallet.mutateAsync({
        amount: parseFloat(amount),
      });
      setReferenceNumber(result.referenceNumber);
      setStep("details");
    } catch (error) {
      toast.error("Failed to initiate fund wallet");
    }
  };

  const handleConfirm = async () => {
    try {
      await confirmTransfer.mutateAsync({
        referenceNumber,
      });
      setStep("confirmed");
      toast.success("Transfer confirmed! Awaiting admin verification.");
      setTimeout(() => navigate("/dashboard"), 3000);
    } catch (error) {
      toast.error("Failed to confirm transfer");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR</h1>
          <Button variant="outline" onClick={() => navigate("/dashboard")}>
            Back to Dashboard
          </Button>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Step 1: Input Amount */}
        {step === "input" && (
          <Card className="p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Fund Your Wallet</h2>
            <p className="text-gray-600 mb-8">Enter the amount you wish to deposit</p>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Amount (₦)
                </label>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="text-lg"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-gray-600">
                  <span className="font-semibold">Note:</span> A unique reference number will be generated for your transfer.
                  Use this reference number as the narration when making your bank transfer.
                </p>
              </div>

              <Button
                className="w-full"
                size="lg"
                onClick={handleInitiate}
                disabled={initiateFundWallet.isPending}
              >
                {initiateFundWallet.isPending ? "Processing..." : "Continue"}
              </Button>
            </div>
          </Card>
        )}

        {/* Step 2: Bank Details */}
        {step === "details" && (
          <Card className="p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Transfer Details</h2>
            <p className="text-gray-600 mb-8">Use the details below to make your bank transfer</p>

            <div className="space-y-6">
              {/* Reference Number */}
              <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-6">
                <p className="text-sm font-semibold text-gray-700 mb-2">
                  Your Unique Reference Number
                </p>
                <div className="flex items-center gap-2">
                  <div className="text-3xl font-bold text-yellow-600 font-mono">
                    {referenceNumber}
                  </div>
                  <button
                    onClick={() => copyToClipboard(referenceNumber)}
                    className="p-2 hover:bg-yellow-100 rounded-lg transition"
                  >
                    {copied ? (
                      <Check className="h-5 w-5 text-green-600" />
                    ) : (
                      <Copy className="h-5 w-5 text-gray-600" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-600 mt-2">
                  Use this as the narration/description for your transfer
                </p>
              </div>

              {/* Bank Details */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">Bank Account Details</h3>
                
                <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">Bank Name</p>
                    <p className="text-lg font-semibold text-gray-900">First Bank Nigeria</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Account Number</p>
                    <div className="flex items-center gap-2">
                      <p className="text-lg font-semibold text-gray-900 font-mono">3012884456</p>
                      <button
                        onClick={() => copyToClipboard("3012884456")}
                        className="p-2 hover:bg-gray-200 rounded-lg transition"
                      >
                        <Copy className="h-4 w-4 text-gray-600" />
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Account Name</p>
                    <p className="text-lg font-semibold text-gray-900">WinR Holdings Ltd</p>
                  </div>
                </div>
              </div>

              {/* Amount */}
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-sm text-gray-600">Amount to Transfer</p>
                <p className="text-3xl font-bold text-blue-600">₦{amount}</p>
              </div>

              {/* Instructions */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold text-green-900 mb-2">Important Instructions:</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>✓ Use the reference number as the transfer narration</li>
                  <li>✓ Transfer the exact amount specified above</li>
                  <li>✓ Keep your transfer receipt for reference</li>
                  <li>✓ Your account will be credited after admin verification</li>
                </ul>
              </div>

              <div className="flex gap-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setStep("input")}
                >
                  Back
                </Button>
                <Button
                  className="flex-1"
                  size="lg"
                  onClick={handleConfirm}
                  disabled={confirmTransfer.isPending}
                >
                  {confirmTransfer.isPending ? "Processing..." : "I Have Made the Transfer"}
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Step 3: Confirmed */}
        {step === "confirmed" && (
          <Card className="p-8 text-center">
            <div className="mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Transfer Confirmed!</h2>
            <p className="text-gray-600 mb-8">
              Your transfer has been recorded. Your account will be credited once our admin team verifies the payment.
            </p>

            <div className="bg-blue-50 rounded-lg p-6 mb-8 text-left">
              <h3 className="font-semibold text-gray-900 mb-4">What's Next?</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>✓ Your reference number: <span className="font-mono font-semibold">{referenceNumber}</span></li>
                <li>✓ Amount: ₦{amount}</li>
                <li>✓ Status: Pending Admin Verification</li>
                <li>✓ You'll receive a notification once verified</li>
              </ul>
            </div>

            <Button
              className="w-full"
              size="lg"
              onClick={() => navigate("/dashboard")}
            >
              Return to Dashboard
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
