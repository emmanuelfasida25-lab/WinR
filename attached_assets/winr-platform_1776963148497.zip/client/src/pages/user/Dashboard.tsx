import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Wallet, TrendingUp, Clock, LogOut } from "lucide-react";

export default function UserDashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: profile } = trpc.user.getProfile.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: balance } = trpc.user.getBalance.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: subscription } = trpc.user.getSubscription.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: transactions } = trpc.user.getTransactionHistory.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const handleLogout = async () => {
    await trpc.auth.logout.useMutation().mutateAsync();
    await utils.auth.me.invalidate();
    logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">{user?.email}</span>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Balance Card */}
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-8 mb-8">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-blue-100 mb-2">Current Balance</p>
              <h2 className="text-5xl font-bold mb-4">₦{balance?.balance || '0'}</h2>
              <div className="flex gap-4">
                <Button
                  variant="secondary"
                  onClick={() => navigate("/fund-wallet")}
                >
                  <Wallet className="h-4 w-4 mr-2" />
                  Fund Wallet
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => navigate("/withdraw")}
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Withdraw
                </Button>
              </div>
            </div>
            <div className="text-right">
              <p className="text-blue-100 mb-2">Account Status</p>
              <div className={`inline-block px-4 py-2 rounded-full font-semibold ${
                balance?.accountStatus === 'active'
                  ? 'bg-green-100 text-green-800'
                  : balance?.accountStatus === 'pending'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {balance?.accountStatus?.toUpperCase() || 'PENDING'}
              </div>
            </div>
          </div>
        </Card>

        {/* Subscription Status */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-2">Subscription Status</p>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {subscription?.subscriptionStatus?.toUpperCase() || 'PENDING'}
                </h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>
                    <span className="font-semibold">Amount:</span> ₦
                    {subscription?.subscriptionAmount || '3,500'}
                  </p>
                  <p>
                    <span className="font-semibold">Last Payment:</span>{' '}
                    {subscription?.lastPaymentDate
                      ? new Date(subscription.lastPaymentDate).toLocaleDateString()
                      : 'N/A'}
                  </p>
                  <p>
                    <span className="font-semibold">Next Due:</span>{' '}
                    {subscription?.nextDueDate
                      ? new Date(subscription.nextDueDate).toLocaleDateString()
                      : 'N/A'}
                  </p>
                </div>
              </div>
              <Clock className="h-8 w-8 text-blue-600" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-gray-900">Quick Actions</h3>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate("/settings")}
              >
                Update Profile
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate("/settings")}
              >
                Bank Details
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate("/settings")}
              >
                Change Password
              </Button>
            </div>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card className="p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Transactions</h3>
          {transactions && transactions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Type</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.slice(0, 5).map((tx) => (
                    <tr key={tx.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-gray-900 capitalize">{tx.type}</td>
                      <td className="py-3 px-4 text-gray-900 font-semibold">₦{tx.amount}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          tx.status === 'confirmed'
                            ? 'bg-green-100 text-green-800'
                            : tx.status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {tx.status?.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        {new Date(tx.date).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-600 text-center py-8">No transactions yet</p>
          )}
        </Card>
      </div>
    </div>
  );
}
