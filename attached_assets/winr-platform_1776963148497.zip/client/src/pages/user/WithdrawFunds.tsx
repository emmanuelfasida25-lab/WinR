import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function WithdrawFunds() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [amount, setAmount] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountName, setAccountName] = useState("");

  const { data: balance } = trpc.user.getBalance.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: withdrawals } = trpc.withdrawal.getWithdrawalHistory.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const requestWithdrawal = trpc.withdrawal.requestWithdrawal.useMutation();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (!bankName || !accountNumber || !accountName) {
      toast.error("Please fill in all bank details");
      return;
    }

    try {
      await requestWithdrawal.mutateAsync({
        amount: parseFloat(amount),
        bankName,
        accountNumber,
        accountName,
      });
      toast.success("Withdrawal request submitted!");
      setAmount("");
      setBankName("");
      setAccountNumber("");
      setAccountName("");
    } catch (error: any) {
      toast.error(error.message || "Failed to request withdrawal");
    }
  };

  const currentBalance = parseFloat(balance?.balance || "0");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR</h1>
          <Button variant="outline" onClick={() => navigate("/dashboard")}>
            Back to Dashboard
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Form */}
          <div className="md:col-span-2">
            <Card className="p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Request Withdrawal</h2>
              <p className="text-gray-600 mb-8">Submit a withdrawal request to transfer funds to your bank account</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Amount */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Amount (₦)
                  </label>
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Available balance: ₦{currentBalance.toLocaleString()}
                  </p>
                </div>

                {/* Bank Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Bank Name
                  </label>
                  <Input
                    type="text"
                    placeholder="e.g., First Bank Nigeria"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    required
                  />
                </div>

                {/* Account Number */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Account Number
                  </label>
                  <Input
                    type="text"
                    placeholder="Your account number"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    required
                  />
                </div>

                {/* Account Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Account Name
                  </label>
                  <Input
                    type="text"
                    placeholder="Your full name as shown in bank"
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    required
                  />
                </div>

                {/* Info */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-gray-700">
                    <span className="font-semibold">Note:</span> Withdrawal requests are subject to admin approval.
                    You will receive a notification once your request is processed.
                  </p>
                </div>

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => navigate("/dashboard")}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1"
                    disabled={requestWithdrawal.isPending}
                  >
                    {requestWithdrawal.isPending ? "Submitting..." : "Submit Request"}
                  </Button>
                </div>
              </form>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Balance Card */}
            <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6">
              <p className="text-blue-100 text-sm mb-2">Available Balance</p>
              <h3 className="text-3xl font-bold mb-4">₦{currentBalance.toLocaleString()}</h3>
              <p className="text-xs text-blue-100">
                This is the amount available for withdrawal
              </p>
            </Card>

            {/* Recent Withdrawals */}
            <Card className="p-6">
              <h3 className="font-bold text-gray-900 mb-4">Recent Requests</h3>
              {withdrawals && withdrawals.length > 0 ? (
                <div className="space-y-3">
                  {withdrawals.slice(0, 3).map((w) => (
                    <div key={w.id} className="pb-3 border-b border-gray-200 last:border-0">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-semibold text-gray-900">₦{w.amount}</span>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          w.withdrawalStatus === 'paid'
                            ? 'bg-green-100 text-green-800'
                            : w.withdrawalStatus === 'approved'
                            ? 'bg-blue-100 text-blue-800'
                            : w.withdrawalStatus === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {w.withdrawalStatus?.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600">
                        {new Date(w.requestedDate!).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-600 text-center py-4">No withdrawal requests yet</p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
