import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { LogOut } from "lucide-react";
import { toast } from "sonner";

export default function AdminPayments() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'confirmed' | 'failed'>('all');

  const { data: allPayments } = trpc.admin.getAllPayments.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const confirmPayment = trpc.admin.confirmPayment.useMutation({
    onSuccess: () => {
      utils.admin.getAllPayments.invalidate();
      toast.success('Payment confirmed successfully!');
    },
    onError: () => {
      toast.error('Failed to confirm payment');
    },
  });

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') {
      navigate("/login");
    }
  }, [isAuthenticated, user, navigate]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return null;
  }

  const handleLogout = async () => {
    await trpc.auth.logout.useMutation().mutateAsync();
    await utils.auth.me.invalidate();
    logout();
    navigate("/");
  };

  const filteredPayments = allPayments?.filter(p => {
    if (filterStatus === 'all') return true;
    return p.paymentStatus === filterStatus;
  }) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR Admin</h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8 py-4">
            <button
              onClick={() => navigate("/admin")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Dashboard
            </button>
            <button
              onClick={() => navigate("/admin/users")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Users
            </button>
            <button
              onClick={() => navigate("/admin/payments")}
              className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-4"
            >
              Payments
            </button>
            <button
              onClick={() => navigate("/admin/withdrawals")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Withdrawals
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Payments & Subscriptions</h2>
          <div className="flex gap-2">
            {(['all', 'pending', 'confirmed', 'failed'] as const).map(status => (
              <Button
                key={status}
                variant={filterStatus === status ? 'default' : 'outline'}
                onClick={() => setFilterStatus(status)}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        <Card className="p-6">
          {filteredPayments && filteredPayments.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">User ID</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Reference</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Method</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPayments.map((p) => (
                    <tr key={p.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-gray-900 font-medium">User #{p.userId}</td>
                      <td className="py-3 px-4 text-gray-900 font-semibold">₦{p.amount}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm font-mono">{p.referenceNumber}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm capitalize">{p.paymentMethod}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          p.paymentStatus === 'confirmed'
                            ? 'bg-green-100 text-green-800'
                            : p.paymentStatus === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {p.paymentStatus?.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        {new Date(p.paymentDate!).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        {p.paymentStatus === 'pending' && (
                          <Button
                            size="sm"
                            onClick={() => confirmPayment.mutate({ paymentId: p.id })}
                            disabled={confirmPayment.isPending}
                          >
                            Confirm
                          </Button>
                        )}
                        {p.paymentStatus !== 'pending' && (
                          <span className="text-gray-500 text-sm">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-600 text-center py-8">No payments found</p>
          )}
        </Card>
      </div>
    </div>
  );
}
