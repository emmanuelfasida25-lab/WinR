import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Users, CreditCard, TrendingUp, LogOut } from "lucide-react";

export default function AdminDashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: stats } = trpc.admin.getDashboardStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const { data: allUsers } = trpc.admin.getAllUsers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const { data: allWithdrawals } = trpc.admin.getAllWithdrawals.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') {
      navigate("/login");
    }
  }, [isAuthenticated, user, navigate]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return null;
  }

  const handleLogout = async () => {
    await trpc.auth.logout.useMutation().mutateAsync();
    await utils.auth.me.invalidate();
    logout();
    navigate("/");
  };

  const pendingWithdrawals = allWithdrawals?.filter(w => w.withdrawalStatus === 'pending') || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR Admin</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">Admin Panel</span>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8 py-4">
            <button
              onClick={() => navigate("/admin")}
              className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-4"
            >
              Dashboard
            </button>
            <button
              onClick={() => navigate("/admin/users")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Users
            </button>
            <button
              onClick={() => navigate("/admin/payments")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Payments
            </button>
            <button
              onClick={() => navigate("/admin/withdrawals")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Withdrawals
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Alert Banner */}
        {pendingWithdrawals.length > 0 && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8">
            <div className="flex">
              <div className="flex-shrink-0">
                <span className="text-yellow-600 font-semibold">⚠</span>
              </div>
              <div className="ml-3">
                <p className="text-sm text-yellow-700">
                  <span className="font-semibold">{pendingWithdrawals.length} pending withdrawal(s)</span> awaiting approval
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-2">Total Users</p>
                <h3 className="text-3xl font-bold text-gray-900">
                  {stats?.totalUsers || 0}
                </h3>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-2">Active Subscribers</p>
                <h3 className="text-3xl font-bold text-gray-900">
                  {stats?.activeSubscribers || 0}
                </h3>
              </div>
              <CreditCard className="h-8 w-8 text-green-600" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-2">Pending Withdrawals</p>
                <h3 className="text-3xl font-bold text-gray-900">
                  {stats?.pendingWithdrawalsCount || 0}
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  ₦{(stats?.pendingWithdrawalsAmount || 0).toLocaleString()}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-600" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-2">Total Paid Out</p>
                <h3 className="text-3xl font-bold text-gray-900">
                  ₦{(stats?.totalPaidOut || 0).toLocaleString()}
                </h3>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </Card>
        </div>

        {/* Recent Signups */}
        <Card className="p-6 mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Signups</h3>
          {allUsers && allUsers.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Name</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Joined</th>
                  </tr>
                </thead>
                <tbody>
                  {allUsers.slice(0, 5).map((u) => (
                    <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-gray-900">{u.name || "N/A"}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          u.accountStatus === 'active'
                            ? 'bg-green-100 text-green-800'
                            : u.accountStatus === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {u.accountStatus?.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-600 text-center py-8">No users yet</p>
          )}
        </Card>

        {/* Pending Withdrawals */}
        {pendingWithdrawals.length > 0 && (
          <Card className="p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Pending Withdrawals</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">User</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Bank</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Account</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingWithdrawals.slice(0, 5).map((w) => (
                    <tr key={w.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-gray-900">User #{w.userId}</td>
                      <td className="py-3 px-4 text-gray-900 font-semibold">₦{w.amount}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">{w.bankName}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">{w.accountNumber}</td>
                      <td className="py-3 px-4">
                        <Button
                          size="sm"
                          onClick={() => navigate("/admin/withdrawals")}
                        >
                          Review
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
