import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { LogOut } from "lucide-react";
import { toast } from "sonner";

export default function AdminWithdrawals() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'paid'>('all');

  const { data: allWithdrawals } = trpc.admin.getAllWithdrawals.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const approveWithdrawal = trpc.admin.approveWithdrawal.useMutation({
    onSuccess: () => {
      utils.admin.getAllWithdrawals.invalidate();
      toast.success('Withdrawal approved!');
    },
    onError: () => {
      toast.error('Failed to approve withdrawal');
    },
  });

  const rejectWithdrawal = trpc.admin.rejectWithdrawal.useMutation({
    onSuccess: () => {
      utils.admin.getAllWithdrawals.invalidate();
      toast.success('Withdrawal rejected!');
    },
    onError: () => {
      toast.error('Failed to reject withdrawal');
    },
  });

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') {
      navigate("/login");
    }
  }, [isAuthenticated, user, navigate]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return null;
  }

  const handleLogout = async () => {
    await trpc.auth.logout.useMutation().mutateAsync();
    await utils.auth.me.invalidate();
    logout();
    navigate("/");
  };

  const filteredWithdrawals = allWithdrawals?.filter(w => {
    if (filterStatus === 'all') return true;
    return w.withdrawalStatus === filterStatus;
  }) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">WinR Admin</h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8 py-4">
            <button
              onClick={() => navigate("/admin")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Dashboard
            </button>
            <button
              onClick={() => navigate("/admin/users")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Users
            </button>
            <button
              onClick={() => navigate("/admin/payments")}
              className="text-gray-600 hover:text-gray-900 pb-4"
            >
              Payments
            </button>
            <button
              onClick={() => navigate("/admin/withdrawals")}
              className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-4"
            >
              Withdrawals
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Withdrawal Requests</h2>
          <div className="flex gap-2">
            {(['all', 'pending', 'approved', 'rejected', 'paid'] as const).map(status => (
              <Button
                key={status}
                variant={filterStatus === status ? 'default' : 'outline'}
                onClick={() => setFilterStatus(status)}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        <Card className="p-6">
          {filteredWithdrawals && filteredWithdrawals.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">User ID</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Bank</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Account</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Requested</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredWithdrawals.map((w) => (
                    <tr key={w.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 text-gray-900 font-medium">User #{w.userId}</td>
                      <td className="py-3 px-4 text-gray-900 font-semibold">₦{w.amount}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">{w.bankName}</td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        <div>{w.accountNumber}</div>
                        <div className="text-xs text-gray-500">{w.accountName}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          w.withdrawalStatus === 'paid'
                            ? 'bg-green-100 text-green-800'
                            : w.withdrawalStatus === 'approved'
                            ? 'bg-blue-100 text-blue-800'
                            : w.withdrawalStatus === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {w.withdrawalStatus?.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-sm">
                        {new Date(w.requestedDate!).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 space-x-2">
                        {w.withdrawalStatus === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => approveWithdrawal.mutate({ withdrawalId: w.id })}
                              disabled={approveWithdrawal.isPending}
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => rejectWithdrawal.mutate({ withdrawalId: w.id })}
                              disabled={rejectWithdrawal.isPending}
                            >
                              Reject
                            </Button>
                          </>
                        )}
                        {w.withdrawalStatus !== 'pending' && (
                          <span className="text-gray-500 text-sm">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-600 text-center py-8">No withdrawals found</p>
          )}
        </Card>
      </div>
    </div>
  );
}
