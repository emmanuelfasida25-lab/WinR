import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Public pages
import Home from "./pages/Home";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";

// User pages
import UserDashboard from "./pages/user/Dashboard";
import FundWallet from "./pages/user/FundWallet";
import WithdrawFunds from "./pages/user/WithdrawFunds";
import UserSettings from "./pages/user/Settings";

// Admin pages
import AdminDashboard from "./pages/admin/Dashboard";
import AdminUsers from "./pages/admin/Users";
import AdminPayments from "./pages/admin/Payments";
import AdminWithdrawals from "./pages/admin/Withdrawals";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path={"/"} component={Home} />
      <Route path={"/login"} component={Login} />
      <Route path={"/signup"} component={Signup} />
      
      {/* User routes */}
      <Route path={"/dashboard"} component={UserDashboard} />
      <Route path={"/fund-wallet"} component={FundWallet} />
      <Route path={"/withdraw"} component={WithdrawFunds} />
      <Route path={"/settings"} component={UserSettings} />
      
      {/* Admin routes */}
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/admin/users"} component={AdminUsers} />
      <Route path={"/admin/payments"} component={AdminPayments} />
      <Route path={"/admin/withdrawals"} component={AdminWithdrawals} />
      
      {/* 404 */}
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
