CREATE TABLE `adminActions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`adminId` int NOT NULL,
	`actionType` varchar(100) NOT NULL,
	`targetUserId` int,
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adminActions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `affiliateWithdrawals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`status` enum('pending','approved','rejected','paid') DEFAULT 'pending',
	`successfulReferralCount` int DEFAULT 0,
	`requestedDate` timestamp DEFAULT (now()),
	`approvedDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `affiliateWithdrawals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `balanceUpdates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`previousBalance` decimal(15,2),
	`newBalance` decimal(15,2) NOT NULL,
	`updateCategory` enum('account_topup','daily_update','other') DEFAULT 'other',
	`note` text,
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `balanceUpdates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`notificationType` varchar(100) NOT NULL,
	`message` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`paymentMethod` enum('manual','automatic') DEFAULT 'manual',
	`referenceNumber` varchar(100) NOT NULL,
	`paymentStatus` enum('pending','confirmed','failed') DEFAULT 'pending',
	`paymentDate` timestamp DEFAULT (now()),
	`confirmedDate` timestamp,
	`confirmedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_referenceNumber_unique` UNIQUE(`referenceNumber`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrerId` int NOT NULL,
	`referredUserId` int NOT NULL,
	`referralStatus` enum('pending','active','inactive') DEFAULT 'pending',
	`earnedAmount` decimal(10,2) DEFAULT '0',
	`payoutStatus` enum('unpaid','paid') DEFAULT 'unpaid',
	`referredDate` timestamp DEFAULT (now()),
	`confirmationDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`subscriptionStatus` enum('active','pending','expired') DEFAULT 'pending',
	`lastPaymentDate` timestamp,
	`nextDueDate` timestamp,
	`subscriptionAmount` decimal(10,2) DEFAULT '3500',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `supportTickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`subject` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`status` enum('open','resolved') DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `supportTickets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`bankName` varchar(100) NOT NULL,
	`accountNumber` varchar(50) NOT NULL,
	`accountName` varchar(100) NOT NULL,
	`withdrawalStatus` enum('pending','approved','rejected','paid') DEFAULT 'pending',
	`requestedDate` timestamp DEFAULT (now()),
	`approvedDate` timestamp,
	`approvedBy` int,
	`isWithdrawalEnabled` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `withdrawals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `phoneNumber` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `bankName` varchar(100);--> statement-breakpoint
ALTER TABLE `users` ADD `accountNumber` varchar(50);--> statement-breakpoint
ALTER TABLE `users` ADD `accountName` varchar(100);--> statement-breakpoint
ALTER TABLE `users` ADD `currentBalance` decimal(15,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `users` ADD `accountStatus` enum('active','pending','inactive') DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `users` ADD `adminNotes` text;