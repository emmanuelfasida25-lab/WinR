import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  bankName: varchar("bankName", { length: 100 }),
  accountNumber: varchar("accountNumber", { length: 50 }),
  accountName: varchar("accountName", { length: 100 }),
  currentBalance: decimal("currentBalance", { precision: 15, scale: 2 }).default("0"),
  accountStatus: mysqlEnum("accountStatus", ["active", "pending", "inactive"]).default("pending"),
  adminNotes: text("adminNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Subscriptions table
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subscriptionStatus: mysqlEnum("subscriptionStatus", ["active", "pending", "expired"]).default("pending"),
  lastPaymentDate: timestamp("lastPaymentDate"),
  nextDueDate: timestamp("nextDueDate"),
  subscriptionAmount: decimal("subscriptionAmount", { precision: 10, scale: 2 }).default("3500"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// Payments table
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["manual", "automatic"]).default("manual"),
  referenceNumber: varchar("referenceNumber", { length: 100 }).notNull().unique(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "confirmed", "failed"]).default("pending"),
  paymentDate: timestamp("paymentDate").defaultNow(),
  confirmedDate: timestamp("confirmedDate"),
  confirmedBy: int("confirmedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// Withdrawals table
export const withdrawals = mysqlTable("withdrawals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  bankName: varchar("bankName", { length: 100 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 50 }).notNull(),
  accountName: varchar("accountName", { length: 100 }).notNull(),
  withdrawalStatus: mysqlEnum("withdrawalStatus", ["pending", "approved", "rejected", "paid"]).default("pending"),
  requestedDate: timestamp("requestedDate").defaultNow(),
  approvedDate: timestamp("approvedDate"),
  approvedBy: int("approvedBy"),
  isWithdrawalEnabled: boolean("isWithdrawalEnabled").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Withdrawal = typeof withdrawals.$inferSelect;
export type InsertWithdrawal = typeof withdrawals.$inferInsert;

// Referrals table
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrerId").notNull(),
  referredUserId: int("referredUserId").notNull(),
  referralStatus: mysqlEnum("referralStatus", ["pending", "active", "inactive"]).default("pending"),
  earnedAmount: decimal("earnedAmount", { precision: 10, scale: 2 }).default("0"),
  payoutStatus: mysqlEnum("payoutStatus", ["unpaid", "paid"]).default("unpaid"),
  referredDate: timestamp("referredDate").defaultNow(),
  confirmationDate: timestamp("confirmationDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

// Affiliate Withdrawals table
export const affiliateWithdrawals = mysqlTable("affiliateWithdrawals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "paid"]).default("pending"),
  successfulReferralCount: int("successfulReferralCount").default(0),
  requestedDate: timestamp("requestedDate").defaultNow(),
  approvedDate: timestamp("approvedDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AffiliateWithdrawal = typeof affiliateWithdrawals.$inferSelect;
export type InsertAffiliateWithdrawal = typeof affiliateWithdrawals.$inferInsert;

// Admin Actions table (audit log)
export const adminActions = mysqlTable("adminActions", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  actionType: varchar("actionType", { length: 100 }).notNull(),
  targetUserId: int("targetUserId"),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdminAction = typeof adminActions.$inferSelect;
export type InsertAdminAction = typeof adminActions.$inferInsert;

// Balance Updates table
export const balanceUpdates = mysqlTable("balanceUpdates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  previousBalance: decimal("previousBalance", { precision: 15, scale: 2 }),
  newBalance: decimal("newBalance", { precision: 15, scale: 2 }).notNull(),
  updateCategory: mysqlEnum("updateCategory", ["account_topup", "daily_update", "other"]).default("other"),
  note: text("note"),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BalanceUpdate = typeof balanceUpdates.$inferSelect;
export type InsertBalanceUpdate = typeof balanceUpdates.$inferInsert;

// Support Tickets table
export const supportTickets = mysqlTable("supportTickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["open", "resolved"]).default("open"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;

// Notifications table
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  notificationType: varchar("notificationType", { length: 100 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;