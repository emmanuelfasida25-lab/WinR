import mysql from 'mysql2/promise';
import { URL } from 'url';

// Parse DATABASE_URL
const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) {
  console.error('DATABASE_URL not set');
  process.exit(1);
}

// Use URL API to parse the connection string
const url = new URL(dbUrl);
const user = url.username;
const password = url.password;
const host = url.hostname;
const port = url.port || '4000';
const database = url.pathname.split('/')[1];

console.log('Connecting to:', host, 'port:', port, 'database:', database);

const connection = await mysql.createConnection({
  host,
  user,
  password,
  database,
  port: parseInt(port),
  ssl: { rejectUnauthorized: false },
});

try {
  // Insert test admin user
  const adminOpenId = 'admin-test-' + Date.now();
  const result = await connection.execute(
    'INSERT INTO users (openId, name, email, loginMethod, role, accountStatus, currentBalance) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [
      adminOpenId,
      'Admin Test User',
      'admin@winr.test',
      'manus',
      'admin',
      'active',
      '999999.00'
    ]
  );

  console.log('✅ Admin user created successfully!');
  console.log('OpenId: ' + adminOpenId);
  console.log('Email: admin@winr.test');
  console.log('Name: Admin Test User');
  console.log('');
  console.log('To login as admin:');
  console.log('1. Go to the login page');
  console.log('2. Click "Sign In with Manus"');
  console.log('3. Use the credentials above');
  console.log('4. You will be redirected to the admin dashboard');

} catch (error) {
  console.error('Error creating admin user:', error.message);
  process.exit(1);
} finally {
  await connection.end();
}
